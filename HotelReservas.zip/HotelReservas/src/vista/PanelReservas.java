package vista;

import java.awt.*;
import java.time.LocalDate;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import modelo.*;

public class PanelReservas extends JPanel {
    private JComboBox<Cliente> cmbClientes;
    private JComboBox<Habitacion> cmbHabitaciones;
    private JTextField txtIngreso, txtSalida;
    private JTable tabla;
    private DefaultTableModel modeloTabla;
    private JButton btnComprobante, btnActualizar;
    private List<Reserva> listaReservas;

    public PanelReservas() {
        setLayout(new BorderLayout());

        JPanel form = new JPanel(new GridLayout(6, 2, 10, 10));
        form.setBorder(BorderFactory.createTitledBorder("Crear Reserva"));

        form.add(new JLabel("Cliente:"));
        cmbClientes = new JComboBox<>();
        form.add(cmbClientes);

        form.add(new JLabel("Habitación:"));
        cmbHabitaciones = new JComboBox<>();
        form.add(cmbHabitaciones);

        form.add(new JLabel("Fecha Ingreso (YYYY-MM-DD):"));
        txtIngreso = new JTextField();
        form.add(txtIngreso);

        form.add(new JLabel("Fecha Salida (YYYY-MM-DD):"));
        txtSalida = new JTextField();
        form.add(txtSalida);

        JButton btnReservar = new JButton("Reservar");
        form.add(btnReservar);

        btnComprobante = new JButton("Ver comprobante de reserva");
        form.add(btnComprobante);

        add(form, BorderLayout.NORTH);

        modeloTabla = new DefaultTableModel(new String[]{"Cliente", "Habitación", "Ingreso", "Salida", "Total"}, 0);
        tabla = new JTable(modeloTabla);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        btnActualizar = new JButton("Recargar listas");
        add(btnActualizar, BorderLayout.SOUTH);

        btnReservar.addActionListener(e -> hacerReserva());
        btnComprobante.addActionListener(e -> mostrarComprobante());
        btnActualizar.addActionListener(e -> {
            cargarListas();
            cargarReservas();
        });

        // Al iniciar el panel
        cargarListas();
        cargarReservas();
    }

    private void cargarListas() {
        cmbClientes.removeAllItems();
        for (Cliente c : ClienteDAO.leerTodos()) {
            cmbClientes.addItem(c);
        }

        cmbHabitaciones.removeAllItems();
        for (Habitacion h : HabitacionDAO.leerTodas()) {
            if (!h.isOcupada()) {
                cmbHabitaciones.addItem(h);
            }
        }
    }

    private void hacerReserva() {
        try {
            Cliente cliente = (Cliente) cmbClientes.getSelectedItem();
            Habitacion habitacion = (Habitacion) cmbHabitaciones.getSelectedItem();
            LocalDate ingreso = LocalDate.parse(txtIngreso.getText());
            LocalDate salida = LocalDate.parse(txtSalida.getText());

            if (salida.isBefore(ingreso)) {
                JOptionPane.showMessageDialog(this, "La fecha de salida debe ser posterior a la de ingreso.");
                return;
            }

            habitacion.setOcupada(true);
            HabitacionDAO.guardar(habitacion); // Guarda como ocupada

            Reserva reserva = new Reserva(cliente, habitacion, ingreso, salida);
            ReservaDAO.guardar(reserva);

            JOptionPane.showMessageDialog(this, "Reserva guardada correctamente.");

            cargarListas();   // actualizar combo habitaciones
            cargarReservas(); // actualizar tabla
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al crear reserva: " + e.getMessage());
        }
    }

    private void cargarReservas() {
        modeloTabla.setRowCount(0);
        List<Cliente> clientes = ClienteDAO.leerTodos();
        List<Habitacion> habitaciones = HabitacionDAO.leerTodas();
        listaReservas = ReservaDAO.leerTodas(clientes, habitaciones);

        for (Reserva r : listaReservas) {
            modeloTabla.addRow(new Object[]{
                r.getCliente().getNombre(),
                r.getHabitacion().getNumero(),
                r.getFechaIngreso(),
                r.getFechaSalida(),
                r.calcularTotal()
            });
        }
    }

    private void mostrarComprobante() {
        int selected = tabla.getSelectedRow();
        if (selected != -1) {
            Reserva reserva = listaReservas.get(selected);
            new VentanaComprobanteReserva(reserva);
        } else {
            JOptionPane.showMessageDialog(this, "Selecciona una reserva de la tabla");
        }
    }
}

