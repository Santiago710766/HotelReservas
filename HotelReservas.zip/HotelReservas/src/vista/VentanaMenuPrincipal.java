package vista;

import javax.swing.*;
import modelo.Administrador;
import modelo.Empresa;
import modelo.Usuario;

public class VentanaMenuPrincipal extends JFrame {

    public VentanaMenuPrincipal(Usuario user, Empresa empresa) {
        setTitle("Menú Principal del Hotel - Rol: " + user.getRol());
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JTabbedPane pestañas = new JTabbedPane();

        pestañas.addTab("Clientes", new PanelClientes());

        if (user instanceof Administrador) {
            pestañas.addTab("Habitaciones", new PanelHabitaciones(empresa));
        }

        pestañas.addTab("Reservas", new PanelReservas());

        if (user instanceof Administrador) {
            pestañas.addTab("Estadísticas", new PanelEstadisticas(empresa));
        }

        add(pestañas);
        setVisible(true);
    }
}

