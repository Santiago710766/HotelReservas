package vista;
import java.awt.*;
import java.util.List;
import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.*;
import modelo.Cliente;
import modelo.ClienteDAO;

public class PanelClientes extends JPanel {
    private JTextField txtNombre, txtApellido, txtCedula, txtEmail, txtBuscar;
    private DefaultTableModel modeloTabla;
    private JTable tabla;
    private TableRowSorter<DefaultTableModel> sorter;

    public PanelClientes() {
        setLayout(new BorderLayout());

        // Panel formulario
        JPanel panelFormulario = new JPanel(new GridLayout(6, 2, 10, 10));
        panelFormulario.setBorder(BorderFactory.createTitledBorder("Registrar Cliente"));

        panelFormulario.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelFormulario.add(txtNombre);

        panelFormulario.add(new JLabel("Apellido:"));
        txtApellido = new JTextField();
        panelFormulario.add(txtApellido);

        panelFormulario.add(new JLabel("Cédula:"));
        txtCedula = new JTextField();
        panelFormulario.add(txtCedula);

        panelFormulario.add(new JLabel("Email:"));
        txtEmail = new JTextField();
        panelFormulario.add(txtEmail);

        JButton btnGuardar = new JButton("Guardar Cliente");
        panelFormulario.add(btnGuardar);

        panelFormulario.add(new JLabel("Buscar:"));
        txtBuscar = new JTextField();
        panelFormulario.add(txtBuscar);

        add(panelFormulario, BorderLayout.NORTH);

        // Tabla
        modeloTabla = new DefaultTableModel(new String[]{"Nombre", "Apellido", "Cédula", "Email"}, 0);
        tabla = new JTable(modeloTabla);
        sorter = new TableRowSorter<>(modeloTabla);
        tabla.setRowSorter(sorter);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        // Eventos
        btnGuardar.addActionListener(e -> guardarCliente());
        txtBuscar.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { filtrar(); }
            public void removeUpdate(DocumentEvent e) { filtrar(); }
            public void changedUpdate(DocumentEvent e) {}
        });

        // Cargar
        cargarClientesEnTabla();
    }

    private void guardarCliente() {
        String nombre = txtNombre.getText();
        String apellido = txtApellido.getText();
        String cedula = txtCedula.getText();
        String email = txtEmail.getText();

        if (nombre.isEmpty() || apellido.isEmpty() || cedula.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios");
            return;
        }

        // Validar si ya existe esa cédula
        List<Cliente> existentes = ClienteDAO.leerTodos();
        for (Cliente c : existentes) {
            if (c.getCedula().equals(cedula)) {
                JOptionPane.showMessageDialog(this, "El cliente ya está registrado.");
                return;
            }
        }

        Cliente cliente = new Cliente(nombre, apellido, cedula, email);
        ClienteDAO.guardar(cliente);
        modeloTabla.addRow(new String[]{nombre, apellido, cedula, email});
        limpiarCampos();
    }

    private void cargarClientesEnTabla() {
        for (Cliente cliente : ClienteDAO.leerTodos()) {
            modeloTabla.addRow(new String[]{
                cliente.getNombre(),
                cliente.getApellido(),
                cliente.getCedula(),
                cliente.getEmail()
            });
        }
    }

    private void limpiarCampos() {
        txtNombre.setText("");
        txtApellido.setText("");
        txtCedula.setText("");
        txtEmail.setText("");
    }

    private void filtrar() {
        String texto = txtBuscar.getText();
        sorter.setRowFilter(RowFilter.regexFilter("(?i)" + texto));
    }
}
