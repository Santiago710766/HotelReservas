package vista;

import java.awt.*;
import java.util.List;
import javax.swing.*;
import modelo.*;

public class PanelEstadisticas extends JPanel {

    private JLabel lblTotalClientes;
    private JLabel lblHabitacionesOcupadas;
    private JLabel lblTotalReservas;
    private JLabel lblHabitacionesIndividuales;
    private JLabel lblHabitacionesDobles;
    private JLabel lblHabitacionesSuites;
    private JLabel lblTotalRecaudado;
    private JButton btnActualizar;

    private Empresa empresa;

    public PanelEstadisticas(Empresa empresa) {
        this.empresa = empresa;

        setLayout(new GridLayout(8, 1, 10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        lblTotalClientes = new JLabel();
        lblHabitacionesOcupadas = new JLabel();
        lblTotalReservas = new JLabel();
        lblHabitacionesIndividuales = new JLabel();
        lblHabitacionesDobles = new JLabel();
        lblHabitacionesSuites = new JLabel();
        lblTotalRecaudado = new JLabel();
        btnActualizar = new JButton("🔄 Recargar estadísticas");

        Font font = new Font("Arial", Font.BOLD, 15);
        lblTotalClientes.setFont(font);
        lblHabitacionesOcupadas.setFont(font);
        lblTotalReservas.setFont(font);
        lblHabitacionesIndividuales.setFont(font);
        lblHabitacionesDobles.setFont(font);
        lblHabitacionesSuites.setFont(font);
        lblTotalRecaudado.setFont(font);
        btnActualizar.setFont(new Font("Arial", Font.PLAIN, 14));

        btnActualizar.addActionListener(e -> actualizarDatos());

        add(lblTotalClientes);
        add(lblHabitacionesOcupadas);
        add(lblTotalReservas);
        add(lblHabitacionesIndividuales);
        add(lblHabitacionesDobles);
        add(lblHabitacionesSuites);
        add(lblTotalRecaudado);
        add(btnActualizar);

        actualizarDatos(); // Cargar al inicio
    }

    private void actualizarDatos() {
        List<Habitacion> habitaciones = empresa.getHabitaciones();
        List<Reserva> reservas = empresa.getReservas();

        int ocupadas = 0;
        int individuales = 0;
        int dobles = 0;
        int suites = 0;
        double totalRecaudado = 0;

        for (Habitacion h : habitaciones) {
            if (h.isOcupada()) ocupadas++;
            switch (h.getTipo()) {
                case INDIVIDUAL -> individuales++;
                case DOBLE -> dobles++;
                case SUITE -> suites++;
            }
        }

        for (Reserva r : reservas) {
            totalRecaudado += r.calcularTotal();
        }

        lblTotalClientes.setText("Total de clientes registrados: " + empresa.getClientes().size());
        lblHabitacionesOcupadas.setText("Habitaciones ocupadas: " + ocupadas);
        lblTotalReservas.setText("Reservas totales: " + reservas.size());
        lblHabitacionesIndividuales.setText("Habitaciones tipo INDIVIDUAL: " + individuales);
        lblHabitacionesDobles.setText("Habitaciones tipo DOBLE: " + dobles);
        lblHabitacionesSuites.setText("Habitaciones tipo SUITE: " + suites);
        lblTotalRecaudado.setText("Total recaudado por reservas: $" + totalRecaudado);
    }
}
