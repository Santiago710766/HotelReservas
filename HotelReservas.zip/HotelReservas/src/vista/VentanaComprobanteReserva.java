package vista;

import javax.swing.*;
import modelo.Reserva;

public class VentanaComprobanteReserva extends JFrame {

    public VentanaComprobanteReserva(Reserva reserva) {
        setTitle("Comprobante de Reserva");
        setSize(400, 300);
        setLocationRelativeTo(null);

        JTextArea area = new JTextArea();
        area.setEditable(false);

        StringBuilder sb = new StringBuilder();
        sb.append("📄 COMPROBANTE DE RESERVA\n\n");
        sb.append("Cliente: ").append(reserva.getCliente().getNombre()).append("\n");
        sb.append("Cédula: ").append(reserva.getCliente().getCedula()).append("\n");
        sb.append("Email: ").append(reserva.getCliente().getEmail()).append("\n\n");
        sb.append("Habitación N°: ").append(reserva.getHabitacion().getNumero()).append("\n");
        sb.append("Tipo: ").append(reserva.getHabitacion().getTipo()).append("\n");
        sb.append("¿Ocupada?: ").append(reserva.getHabitacion().isOcupada() ? "Sí" : "No").append("\n\n");
        sb.append("Fecha Ingreso: ").append(reserva.getFechaIngreso()).append("\n");
        sb.append("Fecha Salida: ").append(reserva.getFechaSalida()).append("\n");
        sb.append("Total a pagar: $").append(reserva.calcularTotal()).append("\n");

        area.setText(sb.toString());
        add(new JScrollPane(area));

        setVisible(true);
    }
}
