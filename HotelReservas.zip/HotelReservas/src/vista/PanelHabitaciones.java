package vista;

import java.awt.*;
import javax.swing.*;
import modelo.*;

public class PanelHabitaciones extends JPanel {

    private JTextField txtNumero;
    private JComboBox<TipoHabitacion> cmbTipo;
    private JCheckBox chkOcupada;
    private JButton btnGuardar;
    private JTextArea areaHabitaciones;

    private Empresa empresa;

    public PanelHabitaciones(Empresa empresa) {
        this.empresa = empresa;

        setLayout(new BorderLayout());

        // Panel superior con campos
        JPanel panelSuperior = new JPanel(new GridLayout(4, 2, 10, 10));
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panelSuperior.add(new JLabel("Número de habitación:"));
        txtNumero = new JTextField();
        panelSuperior.add(txtNumero);

        panelSuperior.add(new JLabel("Tipo de habitación:"));
        cmbTipo = new JComboBox<>(TipoHabitacion.values());
        panelSuperior.add(cmbTipo);

        panelSuperior.add(new JLabel("¿Ocupada?"));
        chkOcupada = new JCheckBox();
        panelSuperior.add(chkOcupada);

        btnGuardar = new JButton("Guardar habitación");
        panelSuperior.add(new JLabel()); // espacio vacío
        panelSuperior.add(btnGuardar);

        add(panelSuperior, BorderLayout.NORTH);

        // Área de texto para mostrar habitaciones registradas
        areaHabitaciones = new JTextArea();
        areaHabitaciones.setEditable(false);
        add(new JScrollPane(areaHabitaciones), BorderLayout.CENTER);

        // Acción del botón
        btnGuardar.addActionListener(e -> guardarHabitacion());

        // Mostrar habitaciones actuales al cargar
        mostrarHabitaciones();
    }

    private void guardarHabitacion() {
        try {
            int numero = Integer.parseInt(txtNumero.getText().trim());

            // Validar que el número no esté ya registrado
            for (Habitacion h : empresa.getHabitaciones()) {
                if (h.getNumero() == numero) {
                    JOptionPane.showMessageDialog(this,
                            "Esa habitación ya está registrada.",
                            "Error",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
            }

            TipoHabitacion tipo = (TipoHabitacion) cmbTipo.getSelectedItem();
            boolean ocupada = chkOcupada.isSelected();

            Habitacion habitacion = new Habitacion(numero, tipo, ocupada);

            empresa.agregarHabitacion(habitacion);
            HabitacionDAO.guardar(habitacion); // 🔥 GUARDA EN EL TXT

            JOptionPane.showMessageDialog(this, "Habitación guardada con éxito.");
            txtNumero.setText("");
            chkOcupada.setSelected(false);
            mostrarHabitaciones();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Número inválido.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarHabitaciones() {
        areaHabitaciones.setText("");
        for (Habitacion h : empresa.getHabitaciones()) {
            areaHabitaciones.append("Habitación " + h.getNumero() + " - " + h.getTipo() +
                    " - Ocupada: " + (h.isOcupada() ? "Sí" : "No") + "\n");
        }
    }
}
