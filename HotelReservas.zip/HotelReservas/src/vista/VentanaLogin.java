package vista;

import java.awt.*;
import javax.swing.*;
import modelo.Administrador;
import modelo.Empresa;
import modelo.Recepcionista;
import modelo.Usuario;

public class VentanaLogin extends JFrame {

    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnIngresar;

    // Creamos la instancia de Empresa aquí
    private Empresa empresa = new Empresa();

    public VentanaLogin() {
        setTitle("Login de Usuario");
        setSize(300, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        panel.add(new JLabel("Usuario:"));
        txtUsuario = new JTextField();
        panel.add(txtUsuario);

        panel.add(new JLabel("Contraseña:"));
        txtContrasena = new JPasswordField();
        panel.add(txtContrasena);

        btnIngresar = new JButton("Ingresar");
        panel.add(new JLabel()); // espacio vacío
        panel.add(btnIngresar);

        add(panel);

        btnIngresar.addActionListener(e -> validarLogin());

        setVisible(true);
    }

    private void validarLogin() {
        String usuario = txtUsuario.getText();
        String contrasena = new String(txtContrasena.getPassword());

        Usuario user;

        if (usuario.equals("admin") && contrasena.equals("123")) {
            user = new Administrador(usuario, contrasena);
        } else if (usuario.equals("recep") && contrasena.equals("123")) {
            user = new Recepcionista(usuario, contrasena);
        } else {
            JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos");
            return;
        }

        JOptionPane.showMessageDialog(this, "Bienvenido, rol: " + user.getRol());
        dispose();

        // Llamamos al nuevo constructor con Usuario y Empresa
        new VentanaMenuPrincipal(user, empresa);
    }
}
