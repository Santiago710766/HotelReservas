package modelo;

public class Cliente {
    private String nombre;
    private String apellido;
    private String cedula;
    private String email;

    public Cliente(String nombre, String apellido, String cedula, String email) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.cedula = cedula;
        this.email = email;
    }

    public String getNombre() { return nombre; }
    public String getApellido() { return apellido; }
    public String getCedula() { return cedula; }
    public String getEmail() { return email; }

    @Override
    public String toString() {
        return nombre + ";" + apellido + ";" + cedula + ";" + email;
    }

    public static Cliente desdeTexto(String linea) {
        String[] partes = linea.split(";");
        if (partes.length != 4) return null;
        return new Cliente(partes[0], partes[1], partes[2], partes[3]);
    }
}
