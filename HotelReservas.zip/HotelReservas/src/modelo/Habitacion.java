package modelo;

public class Habitacion {
    private int numero;
    private TipoHabitacion tipo;
    private boolean ocupada;

    public Habitacion(int numero, TipoHabitacion tipo, boolean ocupada) {
        this.numero = numero;
        this.tipo = tipo;
        this.ocupada = ocupada;
    }

    public int getNumero() {
        return numero;
    }

    public TipoHabitacion getTipo() {
        return tipo;
    }

    public boolean isOcupada() {
        return ocupada;
    }

    public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }

    // Este método se usa para guardar en habitaciones.txt
    @Override
    public String toString() {
        return numero + ";" + tipo + ";" + ocupada;
    }

    // Este método se puede usar para mostrar bonito en JComboBox
    public String mostrarBonito() {
        return "Hab. " + numero + " - " + tipo + (ocupada ? " - Ocupada" : " - Disponible");
    }

    public static Habitacion desdeTexto(String texto) {
        try {
            String[] partes = texto.split(";");
            int numero = Integer.parseInt(partes[0]);
            TipoHabitacion tipo = TipoHabitacion.valueOf(partes[1]);
            boolean ocupada = Boolean.parseBoolean(partes[2]);
            return new Habitacion(numero, tipo, ocupada);
        } catch (Exception e) {
            return null;
        }
    }
}
