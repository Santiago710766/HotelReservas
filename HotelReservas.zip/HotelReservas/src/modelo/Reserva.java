package modelo;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class Reserva implements Pago {
    private Cliente cliente;
    private Habitacion habitacion;
    private LocalDate fechaIngreso;
    private LocalDate fechaSalida;

    public Reserva(Cliente cliente, Habitacion habitacion, LocalDate fechaIngreso, LocalDate fechaSalida) {
        this.cliente = cliente;
        this.habitacion = habitacion;
        this.fechaIngreso = fechaIngreso;
        this.fechaSalida = fechaSalida;
    }

    // Getters
    public Cliente getCliente() {
        return cliente;
    }

    public Habitacion getHabitacion() {
        return habitacion;
    }

    public LocalDate getFechaIngreso() {
        return fechaIngreso;
    }

    public LocalDate getFechaSalida() {
        return fechaSalida;
    }

    // Calcula total a pagar
    @Override
    public double calcularTotal() {
        long dias = ChronoUnit.DAYS.between(fechaIngreso, fechaSalida);
        double precioPorDia = switch (habitacion.getTipo()) {
            case INDIVIDUAL -> 30.0;
            case DOBLE -> 50.0;
            case SUITE -> 100.0;
        };
        return dias * precioPorDia;
    }

    // Para saber si la reserva sigue activa
    public boolean isActiva() {
        return LocalDate.now().isBefore(fechaSalida);
    }

    // Para guardar en archivo
    @Override
    public String toString() {
        return cliente.getCedula() + ";" + habitacion.getNumero() + ";" + fechaIngreso + ";" + fechaSalida;
    }

    // Para leer desde archivo
    public static Reserva desdeTexto(String linea, Cliente cliente, Habitacion habitacion) {
        String[] partes = linea.split(";");
        if (partes.length != 4) return null;
        LocalDate ingreso = LocalDate.parse(partes[2]);
        LocalDate salida = LocalDate.parse(partes[3]);
        return new Reserva(cliente, habitacion, ingreso, salida);
    }
}
