package modelo;

import java.io.*;
import java.util.*;

public class HabitacionDAO {
    private static final String ARCHIVO = "habitaciones.txt";

    public static void guardar(Habitacion habitacion) {
        List<Habitacion> habitaciones = leerTodas();

        boolean existe = false;
        for (int i = 0; i < habitaciones.size(); i++) {
            if (habitaciones.get(i).getNumero() == habitacion.getNumero()) {
                habitaciones.set(i, habitacion);
                existe = true;
                break;
            }
        }

        if (!existe) {
            habitaciones.add(habitacion);
        }

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO))) {
            for (Habitacion h : habitaciones) {
                bw.write(h.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Habitacion> leerTodas() {
        List<Habitacion> lista = new ArrayList<>();
        File archivo = new File(ARCHIVO);
        if (!archivo.exists()) return lista;

        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                Habitacion h = Habitacion.desdeTexto(linea);
                if (h != null) lista.add(h);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lista;
    }
}

