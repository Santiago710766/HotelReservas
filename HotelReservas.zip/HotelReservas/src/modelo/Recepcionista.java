package modelo;

public class Recepcionista extends Usuario {

    public Recepcionista(String nombreUsuario, String contraseña) {
        super(nombreUsuario, contraseña);
    }

    @Override
    public String getRol() {
        return "Recepcionista";
    }
}
