package modelo;

import java.util.ArrayList;
import java.util.List;

public class Empresa {

    private List<Cliente> clientes;
    private List<Habitacion> habitaciones;
    private List<Reserva> reservas;

    public Empresa() {
        this.clientes = new ArrayList<>();
        this.habitaciones = HabitacionDAO.leerTodas(); // 🔧 Cargar habitaciones desde el archivo
        this.reservas = new ArrayList<>();
    }

    public List<Cliente> getClientes() {
        return clientes;
    }

    public List<Habitacion> getHabitaciones() {
        return habitaciones;
    }

    public List<Reserva> getReservas() {
        return reservas;
    }

    public List<Habitacion> getHabitacionesOcupadas() {
        List<Habitacion> ocupadas = new ArrayList<>();
        for (Habitacion h : habitaciones) {
            if (h.isOcupada()) {
                ocupadas.add(h);
            }
        }
        return ocupadas;
    }

    public List<Habitacion> getHabitacionesDisponibles() {
        List<Habitacion> disponibles = new ArrayList<>();
        for (Habitacion h : habitaciones) {
            if (!h.isOcupada()) {
                disponibles.add(h);
            }
        }
        return disponibles;
    }

    public List<Reserva> getReservasActivas() {
        List<Reserva> activas = new ArrayList<>();
        for (Reserva r : reservas) {
            if (r.isActiva()) {
                activas.add(r);
            }
        }
        return activas;
    }

    // Métodos para agregar elementos
    public void agregarCliente(Cliente c) {
        clientes.add(c);
    }

    public void agregarHabitacion(Habitacion h) {
        habitaciones.add(h);
        HabitacionDAO.guardar(h); // 🔧 También guardar automáticamente en el archivo
    }

    public void agregarReserva(Reserva r) {
        reservas.add(r);
    }
}
