package modelo;

public abstract class Usuario {
    protected String nombreUsuario;
    protected String contraseña;

    public Usuario(String nombreUsuario, String contraseña) {
        this.nombreUsuario = nombreUsuario;
        this.contraseña = contraseña;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public boolean validarAcceso(String usuario, String clave) {
        return this.nombreUsuario.equals(usuario) && this.contraseña.equals(clave);
    }

    public abstract String getRol();
}
