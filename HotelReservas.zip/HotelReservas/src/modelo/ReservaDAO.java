package modelo;

import java.io.*;
import java.util.*;

public class ReservaDAO {
    private static final String ARCHIVO = "reservas.txt";

    public static void guardar(Reserva r) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(ARCHIVO, true))) {
            bw.write(r.toString());
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Reserva> leerTodas(List<Cliente> clientes, List<Habitacion> habitaciones) {
        List<Reserva> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split(";");
                if (partes.length == 4) {
                    String cedula = partes[0];
                    int numHab = Integer.parseInt(partes[1]);
                    Cliente cli = clientes.stream().filter(c -> c.getCedula().equals(cedula)).findFirst().orElse(null);
                    Habitacion hab = habitaciones.stream().filter(h -> h.getNumero() == numHab).findFirst().orElse(null);
                    if (cli != null && hab != null) {
                        Reserva r = Reserva.desdeTexto(linea, cli, hab);
                        lista.add(r);
                    }
                }
            }
        } catch (IOException e) {
            // sin archivo, retorna vacío
        }
        return lista;
    }
}
