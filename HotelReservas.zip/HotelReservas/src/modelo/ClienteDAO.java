package modelo;

import java.io.*;
import java.util.*;

public class ClienteDAO {
    private static final String ARCHIVO = "clientes.txt";

    public static void guardar(Cliente cliente) {
        try (FileWriter fw = new FileWriter(ARCHIVO, true);
             BufferedWriter bw = new BufferedWriter(fw)) {
            bw.write(cliente.toString());
            bw.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static List<Cliente> leerTodos() {
        List<Cliente> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(ARCHIVO))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                Cliente cliente = Cliente.desdeTexto(linea);
                if (cliente != null) {
                    lista.add(cliente);
                }
            }
        } catch (IOException e) {
            // Si el archivo no existe, se devuelve lista vacía
        }
        return lista;
    }
}
