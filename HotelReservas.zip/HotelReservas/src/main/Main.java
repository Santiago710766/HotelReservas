package main;

import vista.VentanaLogin;

public class Main {
    public static void main(String[] args) {
        new VentanaLogin();  // Abre la ventana de login
    }
}
